def traduire_romain(nombre):
    """ Renvoie l'écriture décimale du nombre donné en chiffres
    romains """
    if len(nombre) == 1:
        return ... 
    elif romains[nombre[0]] >= ...: 
        return romains[nombre[0]] + ... 
    else:
        return ... 


